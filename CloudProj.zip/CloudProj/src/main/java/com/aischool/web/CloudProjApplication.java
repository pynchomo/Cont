package com.aischool.web;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CloudProjApplication {

	public static void main(String[] args) {
		SpringApplication.run(CloudProjApplication.class, args);
	}

}
